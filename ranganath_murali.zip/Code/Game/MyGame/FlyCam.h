#ifndef EAE6320_FLY_CAMERA_H
#define EAE6320_FLY_CAMERA_H

#include "../../Engine/Graphics/Camera.h"

namespace eae6320
{
	class FlyCamera
	{
	public:
		void Update(Graphics::Camera &camera);
	private:

	};
}
#endif // !EAE6320_FLY_CAMERA_H