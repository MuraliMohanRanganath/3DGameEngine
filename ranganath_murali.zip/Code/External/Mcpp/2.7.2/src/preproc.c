/* preproc.c:   to "pre-preprocess" header files.   */

#pragma MCPP preprocess

#include    "system.H"
#include    "internal.H"

#pragma MCPP put_defines

