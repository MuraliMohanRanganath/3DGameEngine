/*
	This file can be included by a project that wants to use DirectXTex
*/

#ifndef EAE6320_DIRECTXTEXINCLUDES_H
#define EAE6320_DIRECTXTEXINCLUDES_H

#include "DirectXTex/DirectXTex.h"

#endif	// EAE6320_DIRECTXTEXINCLUDES_H
